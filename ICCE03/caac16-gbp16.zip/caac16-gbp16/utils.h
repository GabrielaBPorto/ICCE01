#ifndef __UTILS__
#define __UTILS__

typedef char * string_t;

string_t markerName(string_t baseName, int n);
int isPot2(int n);

#endif
